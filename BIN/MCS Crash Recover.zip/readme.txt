請先將 RunWhenMcsFail.ps1 與 RWMF.BAT 內部設置修改為您所使用的設置。
4WMC建議透過 RWMF.BAT 啟動較為省事。

First modify RunWhenMcsFail.ps1 and RWMF.BAT to your setting please.
4WMC Run via RWMF.BAT is more simplify matters.
