﻿Module Module1

    Sub Main()

        Dim ReadStr1, ReadStr2, WriteStr1 As String
        Dim TmpStr() As String
        Dim dices, numberMax, TotalPoint, DiceOnce As Integer
        Dim RND1 As New Random


        Console.WriteLine("4WMC-SimpleDice sample")
        Console.WriteLine("~say 4WMC-SimpleDice sample is online.")

        Do

            Do 'Fake loop

                ReadStr1 = Console.ReadLine().ToUpper

                TmpStr = ReadStr1.Split("D")
                dices = Val(TmpStr(0))
                numberMax = Val(TmpStr(1))
                If UBound(TmpStr) <> 1 Then
                    Console.WriteLine("~say Rolling dice is xDy. eg. 2D6")
                    Exit Do
                ElseIf (dices <= 0) Or (dices > 9) Then
                    Console.WriteLine("~say Dices should be 1~9. ")
                    Exit Do
                ElseIf (numberMax <= 1) Or (numberMax > 99) Then
                    Console.WriteLine("~say Dices point should be 2~99. ")
                    Exit Do
                End If

                Console.WriteLine("*SENDER~+cm;sender")
                ReadStr2 = Console.ReadLine()

                If (ReadStr2.Length > 7) AndAlso (ReadStr2.Substring(0, 7) <> "SENDER*") Then
                    Console.WriteLine("~say Sorry, I didn't listen clear, please say again.")
                    Exit Do
                ElseIf ReadStr2.Length <= 7 Then
                    Console.WriteLine("~say Sorry, I didn't listen clear, please say again.")
                    Exit Do
                End If


                ReadStr2 = ReadStr2.Substring(7)


                TotalPoint = 0
                WriteStr1 = "~say " + ReadStr2 + " has roll out: "

                For idx01 As Integer = 0 To dices - 1
                    DiceOnce = RND1.Next(numberMax) + 1
                    WriteStr1 += DiceOnce.ToString + ", "
                    TotalPoint += DiceOnce
                Next

                Console.WriteLine(WriteStr1 + "Total: " + TotalPoint.ToString)
                Exit Do

            Loop

        Loop



    End Sub



End Module
