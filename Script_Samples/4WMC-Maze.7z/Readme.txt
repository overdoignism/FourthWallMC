
4WMC迷宮腳本範例 -- 中文說明

原始碼使用方式：


1. 建立一個 Visual Basic.net 的 .net framework 方案，Console 應用

2. 將程式碼置換即可(從 Module1.vb)


程式使用方式：

編譯成執行檔後，在 4WMC EXE console中執行，在遊戲中可以用 /w playerID #xx.exe 方式呼叫。

傳入參數值: 迷宮寬 迷宮長 n 座標x 座標y 座標z


1. 這裡的迷宮長寬是指路徑條數。

2. n參數後來廢棄未使用。請輸入0即可。

3. 如果沒有輸入座標值，建議先將玩家加入 mazeA team。
   還有，迷宮會在玩家座標處生成，朝向東南方。

4. 生成過程中會在地底備份地貌，如果要測試此一功能，請在高度y60以上使用本程式。


最後，請在測試世界上使用本程式，以免未預期的後果損害到你的心血。

--------------------------------------------------------

4WMC Maze generate script -- English

How to use source code:


1. Create a project in Visual Basic.net, with .net framework, Console app.

2. Replace the code (form Module1.vb) .

How to use program exe:

Compile to exe, and execute in 4WMC EXE Console. You may use /w playerID #xx.exe in game.

The argument: mazeWidth mazeLength n coordinateX coordinateY coordinateZ


1. The width and length is mean pathway grid.

2. The n was abandoned and useless. Use 0 to pass.

3. If coordinate is not input, add the player to team [mazeA] is better.
   And Maze will generate at player's coordinate, toward is S-E.

4. It will backup field into underground when generating. If you want to test it,

   Please work at Y > 60. 


Please use it on a test world, to avoid the achievement of your works get damaged.

