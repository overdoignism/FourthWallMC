﻿Module Module1
    Structure MazePos
        Dim XPos As Integer
        Dim YPos As Integer
        Dim ZPos As Integer
        Dim DefineData As Integer
    End Structure

    Dim IamQuit As Boolean

    Sub Main()

        Dim MazeX, MazeY, MazeZ, MazeW, MazeL, FastAct As Integer

        MazeW = 9
        If My.Application.CommandLineArgs.Count >= 1 Then MazeW = Val(My.Application.CommandLineArgs.Item(0))
        If MazeW < 4 Then MazeW = 4

        MazeL = 9
        If My.Application.CommandLineArgs.Count >= 2 Then MazeL = Val(My.Application.CommandLineArgs.Item(1))
        If MazeL < 4 Then MazeL = 4

        FastAct = 0
        If My.Application.CommandLineArgs.Count >= 3 Then FastAct = Val(My.Application.CommandLineArgs.Item(2))

        If My.Application.CommandLineArgs.Count >= 4 Then MazeX = Val(My.Application.CommandLineArgs.Item(3))
        If My.Application.CommandLineArgs.Count >= 5 Then MazeY = Val(My.Application.CommandLineArgs.Item(4))
        If My.Application.CommandLineArgs.Count >= 6 Then MazeZ = Val(My.Application.CommandLineArgs.Item(5))

        MakeMaze(MazeW, MazeL, FastAct, MazeX, MazeY, MazeZ)

    End Sub
    Sub MakeMaze(Xwidth As Integer, Zlength As Integer, FastAct As Integer, MazeX As Integer, MazeY As Integer, MazeZ As Integer)


        '=============== Maze generator Start (Data Structure) 開始產生迷宮(資料結構 )=========================

        'We use like Kruskal's algorithm
        '這裡採用類克魯斯克爾演算法
        '感謝啾啾鞋的影片

        Dim Xwidth_Maze_Total As Integer = (Xwidth * 2)
        Dim Zlength_Maze_Total As Integer = (Zlength * 2)

        'Maze_Array is Main data, value < 0 mean wall
        'Maze_Array 是主資料，值<0 代表牆
        Dim Maze_Array(Xwidth_Maze_Total)() As Integer

        Dim MazeCounter As Integer
        Dim MazeWall() As MazePos 'Use for easy random get wall
        Dim MazeWallCounter As Integer

        Dim Wall_Val As Integer = (Xwidth * 100) * -1
        Dim RndNum As New Random()
        Dim TmpIDXw1, TmpIDXw2, TmpIDXw3 As Integer
        ReDim Maze_Array(Xwidth_Maze_Total)(Zlength_Maze_Total)

        For TmpIDXw1 = 0 To Xwidth_Maze_Total
            ReDim Maze_Array(TmpIDXw1)(Zlength_Maze_Total)
        Next

        MazeCounter = 1
        MazeWallCounter = 0

        For TmpIDXw1 = 0 To Xwidth_Maze_Total
            For TmpIDXw2 = 0 To Zlength_Maze_Total

                If (TmpIDXw2 Mod 2 = 0) Then
                    Maze_Array(TmpIDXw1)(TmpIDXw2) = Wall_Val
                End If

                If (TmpIDXw1 Mod 2 = 0) Then
                    Maze_Array(TmpIDXw1)(TmpIDXw2) += Wall_Val
                End If

                If (TmpIDXw1 = 0) OrElse (TmpIDXw1 = Xwidth_Maze_Total) Then
                    Maze_Array(TmpIDXw1)(TmpIDXw2) += Wall_Val
                End If

                If (TmpIDXw2 = 0) OrElse (TmpIDXw2 = Zlength_Maze_Total) Then
                    Maze_Array(TmpIDXw1)(TmpIDXw2) += Wall_Val
                End If

                If Maze_Array(TmpIDXw1)(TmpIDXw2) = 0 Then
                    Maze_Array(TmpIDXw1)(TmpIDXw2) = MazeCounter
                    MazeCounter += 1
                ElseIf Maze_Array(TmpIDXw1)(TmpIDXw2) = Wall_Val Then
                    ReDim Preserve MazeWall(MazeWallCounter)
                    MazeWall(MazeWallCounter).XPos = TmpIDXw1
                    MazeWall(MazeWallCounter).ZPos = TmpIDXw2
                    MazeWallCounter += 1
                End If

            Next
        Next

        Dim MazeWallMax As Integer
        Dim MazeWallTmp As MazePos
        Dim RndVAL1, RndVAL2 As Integer
        Dim TestVal, TestLastVal As Integer
        Dim EqValue As Integer
        Dim If_No_Need_Loop As Boolean

        Do
            MazeWallMax = UBound(MazeWall)
            EqValue = Wall_Val

            For TmpIDXw1 = 0 To MazeWallMax * 20
                RndVAL1 = RndNum.Next(0, MazeWallMax + 1)
                RndVAL2 = RndNum.Next(0, MazeWallMax + 1)
                MazeWallTmp = MazeWall(RndVAL1)
                MazeWall(RndVAL1) = MazeWall(RndVAL2)
                MazeWall(RndVAL2) = MazeWallTmp
            Next

            Dim BreakWall As MazePos = MazeWall(MazeWallMax)

            Dim FourWay(3) As Integer
            FourWay(0) = Maze_Array(BreakWall.XPos + 1)(BreakWall.ZPos)
            FourWay(1) = Maze_Array(BreakWall.XPos - 1)(BreakWall.ZPos)
            FourWay(2) = Maze_Array(BreakWall.XPos)(BreakWall.ZPos + 1)
            FourWay(3) = Maze_Array(BreakWall.XPos)(BreakWall.ZPos - 1)

            For TmpIDXw1 = 0 To 3
                For TmpIDXw2 = TmpIDXw1 + 1 To 3
                    If (FourWay(TmpIDXw1) > 0) And (FourWay(TmpIDXw2) > 0) Then
                        If FourWay(TmpIDXw1) <> FourWay(TmpIDXw2) Then
                            EqValue = FourWay(TmpIDXw1)
                        End If
                    End If
                Next
            Next

            If EqValue < 0 Then
                ReDim Preserve MazeWall(MazeWallMax - 1)
            Else
                For TmpIDXw1 = 1 To Xwidth_Maze_Total - 1
                    For TmpIDXw2 = 1 To Zlength_Maze_Total - 1
                        For TmpIDXw3 = 0 To 3
                            If Maze_Array(TmpIDXw1)(TmpIDXw2) = FourWay(TmpIDXw3) Then
                                If (Maze_Array(TmpIDXw1)(TmpIDXw2) <> Wall_Val) AndAlso (Maze_Array(TmpIDXw1)(TmpIDXw2) > 0) Then
                                    Maze_Array(TmpIDXw1)(TmpIDXw2) = EqValue
                                End If
                            End If
                        Next
                    Next
                Next

                Maze_Array(BreakWall.XPos)(BreakWall.ZPos) = EqValue

                ReDim Preserve MazeWall(MazeWallMax - 1)
                TestLastVal = Maze_Array(1)(1)

                Do 'FakeLoop
                    For TmpIDXw1 = 1 To Xwidth_Maze_Total - 1
                        For TmpIDXw2 = 1 To Zlength_Maze_Total - 1
                            TestVal = Maze_Array(TmpIDXw1)(TmpIDXw2)
                            If TestVal > 0 Then
                                If TestVal <> TestLastVal Then
                                    Exit Do
                                End If
                            End If
                        Next
                    Next
                    If_No_Need_Loop = True
                    Exit Do
                Loop

            End If

            If If_No_Need_Loop Then Exit Do

        Loop
        '=============== Maze generator end 迷宮產生結束 =========================



        '====================== Output to MCServer 將結果輸出至麥塊 ================================

        Dim Xpos, Ypos, Zpos As Long 'Start block 起始方塊
        Dim XposL, ZposL As Long 'End block 結束方塊
        Dim TraceInX, TraceInZ As Integer
        Dim TraceOutX, TraceOutZ As Integer
        Dim SpaceXZ() As MazePos
        Dim SXZcount As Integer
        Dim CommandSender As String
        Dim TraceOut(0) As MazePos
        Dim TraceOutIdx As Integer
        '========================== Try to find out the command sender(player) in different way, and take him into mazeA team
        '========================== 試著在不同方式下找出命令執行者(player), 並將他加入 mazeA team
        Console.WriteLine("~+cm;sender")
        CommandSender = Console.ReadLine()
        Console.WriteLine("~team add mazeA")

        If CommandSender <> "" Then
            If InStr(CommandSender, "CommandBlock at") = 0 Then
                If InStr(CommandSender, "CONSOLE") = 0 Then
                    Console.WriteLine("~team join mazeA " + CommandSender)
                End If
            End If
        End If

        If MazeY <> 0 Then
            Console.WriteLine("~execute positioned " + Xpos.ToString + " " + Ypos.ToString + " " + Zpos.ToString + " run team join mazeA @p")
        End If

        '=========Try to find out the command sender pos
        '=========試著定義出執行者的座標

        If MazeX = 0 Then
            Console.WriteLine("*maze~+rr;has the following;;;execute run data get entity @p[team=mazeA] Pos[0]")
            Xpos = Get_Legal_Val_Back()
        Else
            Xpos = MazeX
        End If

        If MazeY = 0 Then
            Console.WriteLine("*maze~+rr;has the following;;;execute run data get entity @p[team=mazeA] Pos[1]")
            Ypos = Get_Legal_Val_Back()
        Else
            Ypos = MazeY
        End If

        If MazeZ = 0 Then
            Console.WriteLine("*maze~+rr;has the following;;;execute run data get entity @p[team=mazeA] Pos[2]")
            Zpos = Get_Legal_Val_Back()
        Else
            Zpos = MazeZ
        End If

        Xpos += 1
        Zpos += 1

        'Actually maze Size (in block) 真實迷宮大小
        XposL = Xpos + (Xwidth_Maze_Total * 1.5)
        ZposL = Zpos + (Zlength_Maze_Total * 1.5)


        '================================== Backup field 備份場地
        Console.WriteLine("~execute run clone " + (Xpos - 1).ToString + " " + (Ypos - 4).ToString + " " + (Zpos - 1).ToString +
                  " " + (XposL + 1).ToString + " " + (Ypos + 0).ToString + " " + (ZposL + 1).ToString +
                  " " + (Xpos - 1).ToString + " " + (Ypos - 50).ToString + " " + (Zpos - 1).ToString + " replace")

        Console.WriteLine("~execute run clone " + (Xpos - 1).ToString + " " + (Ypos + 1).ToString + " " + (Zpos - 1).ToString +
                  " " + (XposL + 1).ToString + " " + (Ypos + 5).ToString + " " + (ZposL + 1).ToString +
                  " " + (Xpos - 1).ToString + " " + (Ypos - 40).ToString + " " + (Zpos - 1).ToString + " replace")

        Console.WriteLine("~execute run clone " + (Xpos - 1).ToString + " " + (Ypos + 6).ToString + " " + (Zpos - 1).ToString +
                  " " + (XposL + 1).ToString + " " + (Ypos + 10).ToString + " " + (ZposL + 1).ToString +
                  " " + (Xpos - 1).ToString + " " + (Ypos - 30).ToString + " " + (Zpos - 1).ToString + " replace")


        '================================== site preparation 整理場地

        'Includ generated block. 包含產生出來的方塊
        Dim WhatToClean() As String = {"grass", "sweet_berry_bush", "tall_grass", "#minecraft:flowers", "chest", "chiseled_stone_bricks",
            "large_fern", "#minecraft:logs", "snow", "mossy_stone_bricks", "stone_bricks", "glowstone", "cracked_stone_bricks"}

        For Each CleanTmp As String In WhatToClean
            Console.WriteLine("~execute run fill " + (Xpos - 1).ToString + " " + (Ypos - 4).ToString + " " + (Zpos - 1).ToString +
                  " " + (XposL + 1).ToString + " " + (Ypos + 0).ToString + " " + (ZposL + 1).ToString + " air replace " + CleanTmp)
            Console.WriteLine("~execute run fill " + (Xpos - 1).ToString + " " + (Ypos + 1).ToString + " " + (Zpos - 1).ToString +
                              " " + (XposL + 1).ToString + " " + (Ypos + 5).ToString + " " + (ZposL + 1).ToString + " air replace " + CleanTmp)
            Console.WriteLine("~execute run fill " + (Xpos - 1).ToString + " " + (Ypos + 6).ToString + " " + (Zpos - 1).ToString +
                  " " + (XposL + 1).ToString + " " + (Ypos + 10).ToString + " " + (ZposL + 1).ToString + " air replace " + CleanTmp)
        Next

        WhatToClean = {"#minecraft:logs", "#minecraft:leaves"}
        For Each CleanTmp As String In WhatToClean
            Console.WriteLine("~execute run fill " + (Xpos - 1).ToString + " " + (Ypos - 3).ToString + " " + (Zpos - 1).ToString +
                  " " + (XposL + 1).ToString + " " + (Ypos + 3).ToString + " " + (ZposL + 1).ToString + " air replace " + CleanTmp)
            Console.WriteLine("~execute run fill " + (Xpos - 1).ToString + " " + (Ypos + 4).ToString + " " + (Zpos - 1).ToString +
                  " " + (XposL + 1).ToString + " " + (Ypos + 10).ToString + " " + (ZposL + 1).ToString + " air replace " + CleanTmp)
        Next

        Console.WriteLine("~execute positioned " + ((XposL + Xpos) / 2).ToString + " " + Ypos.ToString + " " +
                          ((ZposL + Zpos) / 2).ToString + " run kill @e[type=!player,distance=..25]")

        '=========================================== Start draw maze in game world 開始在遊戲內繪製迷宮

        'Random use below block to make. 隨機採用以下磚塊製作
        Dim BlockStrs() As String = {"stone_bricks", "stone_bricks", "stone_bricks", "stone_bricks", "stone_bricks", "stone_bricks", "stone_bricks", "stone_bricks",
        "stone_bricks", "stone_bricks", "stone_bricks", "mossy_stone_bricks", "cracked_stone_bricks", "stone_bricks", "stone_bricks", "stone_bricks", "stone_bricks",
         "stone_bricks", "stone_bricks", "stone_bricks", "cracked_stone_bricks", "stone_bricks", "stone_bricks"}

        Dim DoubleWx, DoubleWz As Integer
        Dim RealzCount As Integer
        Dim RealxCount As Integer

        For TmpIDXw3 = 0 To 2

            RealxCount = 0

            For TmpIDXw1 = 0 To Xwidth_Maze_Total

                For DoubleWx = 0 To TmpIDXw1 Mod 2

                    RealxCount += DoubleWx 'The double with for pathway in X 道路拓寬為兩倍寬
                    RealzCount = 0

                    For TmpIDXw2 = 0 To Zlength_Maze_Total
                        TestVal = Maze_Array(TmpIDXw1)(TmpIDXw2)

                        For DoubleWz = 0 To TmpIDXw2 Mod 2

                            RealzCount += DoubleWz 'The double with for pathway in Z 道路拓寬為兩倍寬

                            If TestVal < 0 Then

                                If (TmpIDXw1 = 0) And (TmpIDXw2 = (Zlength_Maze_Total \ 2)) Then 'The entrance 入口

                                    TraceInX = TmpIDXw1 + Xpos + RealxCount 'entrance tracing 入口追蹤變數
                                    TraceInZ = TmpIDXw2 + Zpos + RealzCount

                                ElseIf (TmpIDXw1 = Xwidth_Maze_Total) And (TmpIDXw2 = (Zlength_Maze_Total \ 2)) Then 'The Exit 出口

                                    TraceOutX = TmpIDXw1 + Xpos + RealxCount 'entrance tracing 出口追蹤變數
                                    TraceOutZ = TmpIDXw2 + Zpos + RealzCount

                                    'summon falling block (chiseled_stone_bricks) overlap exit. 出口用磚塊(chiseled_stone_bricks)先蓋掉
                                    Console.WriteLine("~execute run summon falling_block " + TraceOutX.ToString + " " + (Ypos + TmpIDXw3 + 8).ToString + " " +
                                                              TraceOutZ.ToString + " {BlockState:{Name:""minecraft:chiseled_stone_bricks""},Time:1}")

                                    'Record the exit 紀錄出口位置
                                    If TmpIDXw3 = 0 Then
                                        ReDim Preserve TraceOut(TraceOutIdx)
                                        TraceOut(TraceOutIdx).XPos = TraceOutX
                                        TraceOut(TraceOutIdx).ZPos = TraceOutZ
                                        TraceOutIdx += 1
                                    End If

                                Else

                                    'summon falling block for wall 召喚浮空墜落磚塊蓋牆
                                    Dim WhatBlock As String = BlockStrs(RndNum.Next(0, UBound(BlockStrs) + 1))
                                    Console.WriteLine("~execute run summon falling_block " + (TmpIDXw1 + Xpos + RealxCount).ToString + " " + (Ypos + TmpIDXw3 + 8).ToString + " " +
                                                              (TmpIDXw2 + Zpos + RealzCount).ToString + " {BlockState:{Name:""minecraft:" + WhatBlock + """},Time:1}")
                                End If

                            Else

                                If TmpIDXw3 = 2 Then

                                    'Record the blank (pathway) 將空白塊(走道)記錄下來
                                    ReDim Preserve SpaceXZ(SXZcount)
                                    SpaceXZ(SXZcount).XPos = TmpIDXw1 + Xpos + RealxCount
                                    SpaceXZ(SXZcount).ZPos = TmpIDXw2 + Zpos + RealzCount
                                    SXZcount += 1

                                End If

                            End If
                        Next
                    Next
                Next
            Next
        Next

        '============================== Place chest and Mobs (放置寶箱與怪物)

        'Defind the chest with book NBT.
        '定義箱子與書的NBT
        Dim TooLongString() As String =
            {"chest{Items:[{Slot:13b,id:""minecraft:writable_book"",Count:1b,tag:{pages: [""Everything in the dream. 睡吧夢裡什麼都有""], display:{Lore:['{""text"":""The most Secret!""}'],Name:'{""text"":""How to become a popular youtuber/vtuber""}'}}}]}",
             "chest{Items:[{Slot:13b,id:""minecraft:writable_book"",Count:1b,tag:{pages: [""Have a rich dad first. 你爸姓連嗎?""], display:{Lore:['{""text"":""The most Secret!""}'],Name:'{""text"":""How to become rich""}'}}}]}",
             "chest{Items:[{Slot:13b,id:""minecraft:writable_book"",Count:1b,tag:{pages: [""Know yourself is better. 撒泡尿照自己吧""], display:{Lore:['{""text"":""The most Secret!""}'],Name:'{""text"":""How to get a girlfriend""}'}}}]}"}

        'Shuffle the blank block (disturb sequence) 將空白塊順序洗牌
        Dim TmpXZ As MazePos
        For TmpIDXw1 = 0 To 1000
            TmpIDXw2 = RndNum.Next(0, UBound(SpaceXZ) + 1)
            TmpIDXw3 = RndNum.Next(0, UBound(SpaceXZ) + 1)
            TmpXZ = SpaceXZ(TmpIDXw2)
            SpaceXZ(TmpIDXw2) = SpaceXZ(TmpIDXw3)
            SpaceXZ(TmpIDXw3) = TmpXZ
        Next

        'Top 3 blank block become cheast 抽前三成為箱子
        'Put red_nether_brick_slab  先放置 red_nether_brick_slab
        For TmpIDXw2 = 0 To 2
            Console.WriteLine("~execute run summon falling_block " + SpaceXZ(TmpIDXw2).XPos.ToString + " " + (Ypos + 8).ToString + " " +
                                                     SpaceXZ(TmpIDXw2).ZPos.ToString + " {BlockState:{Name:""minecraft:red_nether_brick_slab""},Time:1}")
        Next

        'Make mobs from 4th blank block
        '再從第四個空白塊開始產生怪物
        Dim MobStrs() As String = {"zombie", "zombie", "zombie", "skeleton", "spider"}
        Dim HowManyMobs As Integer = ((Xwidth_Maze_Total * Zlength_Maze_Total) \ 12)

        For TmpIDXw1 = 3 To HowManyMobs + 3
            Dim What2summon As String = MobStrs(RndNum.Next(0, UBound(MobStrs) + 1))
            Console.WriteLine("~execute run summon " + What2summon + " " + SpaceXZ(TmpIDXw1).XPos.ToString + " " +
                                                      (Ypos + 5).ToString + " " + SpaceXZ(TmpIDXw1).ZPos.ToString.ToString)
        Next


        'wait tag fall and make night effect 等待一切掉落並同時製造入夜效果
        Console.WriteLine("~execute at @p[team=mazeA] run playsound minecraft:entity.lightning_bolt.thunder weather @p[team=mazeA] ~ ~ ~ 1 0.3")
        For TmpIDXw1 = 0 To 6
            Console.WriteLine("~time set " + (TmpIDXw1 * 100 + 12800).ToString)
            System.Threading.Thread.Sleep(400)
        Next

        'Replace red_nether_brick_slab to chest with book 
        '將 red_nether_brick_slab 置換為放書的箱子
        For TmpIDXw2 = 0 To 2
            Console.WriteLine("~fill " + SpaceXZ(TmpIDXw2).XPos.ToString + " " + (Ypos - 4).ToString + " " + SpaceXZ(TmpIDXw2).ZPos.ToString + " " +
                              SpaceXZ(TmpIDXw2).XPos.ToString + " " + (Ypos + 5).ToString + " " + SpaceXZ(TmpIDXw2).ZPos.ToString + " " +
                              TooLongString(TmpIDXw2) + " replace red_nether_brick_slab")
        Next

        '=========================================================== Start the story 開始故事
        Console.WriteLine("~execute at @p[team=mazeA] run tellraw @e[distance=..5,type=player] {""text"":"" MaO: Welcome my Maze, Haachamachama~ no, Hahahahaa!"",""color"":""yellow""}")
        Console.WriteLine("~execute at @p[team=mazeA] run tellraw @e[distance=..5,type=player] {""text"":""魔王: 歡迎來到我的迷宮，哈洽馬洽馬...不對，哈哈哈哈!"",""color"":""yellow""}")
        Console.WriteLine("~execute at @p[team=mazeA] run tellraw @e[distance=..5,type=player] {""text"":"" MaO: There are 3 my secret books here, if you want leave, find out them."",""color"":""yellow""}")
        Console.WriteLine("~execute at @p[team=mazeA] run tellraw @e[distance=..5,type=player] {""text"":""魔王: 這裡放著我的三本祕笈，全部找到才能離開。"",""color"":""yellow""}")
        Console.WriteLine("~execute at @p[team=mazeA] run tellraw @e[distance=..5,type=player] {""text"":"" MaO: Are you have dare to challenge?"",""color"":""yellow""}")
        Console.WriteLine("~execute at @p[team=mazeA] run tellraw @e[distance=..5,type=player] {""text"":""魔王: 你有膽挑戰嗎?"",""color"":""yellow""}")

        'Find Y of chest 找出箱子的Y
        For TmpIDXw2 = 0 To 2
            For TmpIDXw3 = (Ypos - 4) To (Ypos + 5)
                Console.WriteLine("*maze~+rr;has the following;;is not a block;execute run data get block " + SpaceXZ(TmpIDXw2).XPos.ToString + " " + TmpIDXw3.ToString + " " + SpaceXZ(TmpIDXw2).ZPos.ToString)
                If Get_IF_Its_Cheast() = 1 Then
                    SpaceXZ(TmpIDXw2).YPos = TmpIDXw3
                    SpaceXZ(TmpIDXw2).DefineData = 1
                    Console.WriteLine(TmpIDXw3)
                    Exit For
                End If
            Next
        Next

        ' Start to trace player 開始追蹤玩家
        Dim XposPlayer, ZposPlayer As Integer

        Do
            Console.WriteLine("*maze~+rr;has the following;;;execute run data get entity @p[team=mazeA] Pos[0]")
            XposPlayer = Get_Legal_Val_Back()
            System.Threading.Thread.Sleep(50)
            Console.WriteLine("*maze~+rr;has the following;;;execute run data get entity @p[team=mazeA] Pos[2]")
            ZposPlayer = Get_Legal_Val_Back()
            System.Threading.Thread.Sleep(50)

            'When player arrivals at entrance. 當玩家到達入口
            If Math.Abs(XposPlayer - TraceInX) <= 2 And Math.Abs(ZposPlayer - TraceInZ) <= 2 Then
                Console.WriteLine("~execute at @p[team=mazeA] run tellraw @e[distance=..5,type=player] {""text"":""Dryad: I am a Dryad. I will give you a bit the hope of light."",""color"":""green""}")
                Console.WriteLine("~execute at @p[team=mazeA] run tellraw @e[distance=..5,type=player] {""text"":""森精: 我是森之精靈，我會給你一點希望之光"",""color"":""green""}")
                System.Threading.Thread.Sleep(500)
                Console.WriteLine("~execute at @p[team=mazeA] run tellraw @e[distance=..5,type=player] {""text"":""Dryad: I will turn the mossy which around you into light stone."",""color"":""green""}")
                Console.WriteLine("~execute at @p[team=mazeA] run tellraw @e[distance=..5,type=player] {""text"":""森精: 我會讓你身邊的青苔石發光"",""color"":""green""}")
                Exit Do
            End If

        Loop


        '============= Trace player for get books, light-on moss stone, and at exit. 追蹤玩家取得書, 點亮石頭, 到達出口
        Dim PlayerTakeBooks As Integer
        Dim PlayerXpos, PlayerZpos As Integer

        Do

            'light-on moss stone 點亮青苔石
            Console.WriteLine("~execute at @p[team=mazeA] run fill ~-2 ~-2 ~-2 ~2 ~2 ~2 glowstone replace mossy_stone_bricks")

            'monitor player get books 監視箱子與書
            For TmpIDXw2 = 0 To 2
                If SpaceXZ(TmpIDXw2).DefineData = 1 Then
                    Console.WriteLine("*maze~+rr;has the following;;is not a block;execute run data get block " + SpaceXZ(TmpIDXw2).XPos.ToString + " " + SpaceXZ(TmpIDXw2).YPos.ToString + " " + SpaceXZ(TmpIDXw2).ZPos.ToString)
                    System.Threading.Thread.Sleep(50)
                    If Get_IF_Its_Cheast() = 2 Then
                        SpaceXZ(TmpIDXw2).DefineData = 2
                        PlayerTakeBooks += 1
                    End If
                End If
            Next

            'Player get all books, open exit 玩家取得3本書後開啟出口
            If PlayerTakeBooks = 3 Then
                Console.WriteLine("~execute at @p[team=mazeA] run playsound minecraft:block.coral_block.break weather @p[team=mazeA] ~ ~ ~ 1 0.3")
                Console.WriteLine("~execute at @p[team=mazeA] run tellraw @e[distance=..5,type=player] {""text"":""Dryad: You find all the book! The exit is open! Let's get out here!"",""color"":""green""}")
                Console.WriteLine("~execute at @p[team=mazeA] run tellraw @e[distance=..5,type=player] {""text"":""森精: 你找到全部的書了! 出口已經打開，我們離開這裡吧!"",""color"":""green""}")

                PlayerTakeBooks = 0

                For TmpIDXw2 = 0 To UBound(TraceOut)
                    Console.WriteLine("~execute run fill " + TraceOut(TmpIDXw2).XPos.ToString + " " + (Ypos - 4).ToString + " " + TraceOut(TmpIDXw2).ZPos.ToString + " " +
                    TraceOut(TmpIDXw2).XPos.ToString + " " + (Ypos + 5).ToString + " " + TraceOut(TmpIDXw2).ZPos.ToString + " air replace chiseled_stone_bricks")
                Next

            End If

            'Monitor player if hit exit 監視玩家達到出口
            Console.WriteLine("*maze~+rr;has the following;;;execute run data get entity @p[team=mazeA] Pos[0]")
            PlayerXpos = Get_Legal_Val_Back()
            System.Threading.Thread.Sleep(50)

            Console.WriteLine("*maze~+rr;has the following;;;execute run data get entity @p[team=mazeA] Pos[2]")
            PlayerZpos = Get_Legal_Val_Back()
            System.Threading.Thread.Sleep(50)

            For TmpIDXw2 = 0 To UBound(TraceOut)

                If Math.Abs(PlayerXpos - (TraceOut(TmpIDXw2).XPos + 1)) <= 0 And Math.Abs(PlayerZpos - (TraceOut(TmpIDXw2).ZPos + 1)) <= 0 Then
                    'Player finished the maze game
                    '玩家結束迷宮遊戲
                    Console.WriteLine("~execute at @p[team=mazeA] run playsound minecraft:block.bell.use weather @p[team=mazeA] ~ ~ ~ 1 0.3")
                    Console.WriteLine("~execute at @p[team=mazeA] run tellraw @e[distance=..5,type=player] {""text"":""Dryad: Good, you are leaving the maze!"",""color"":""green""}")
                    Console.WriteLine("~execute at @p[team=mazeA] run tellraw @e[distance=..5,type=player] {""text"":""森精: 太好了，你走出了迷宮！"",""color"":""green""}")
                    Console.WriteLine("~time set 6000")
                    Console.WriteLine("~team empty mazeA")
                    Exit Do

                End If
            Next

        Loop


        '================================== Recovery field 還原場地
        Console.WriteLine("~execute run clone " + (Xpos - 1).ToString + " " + (Ypos - 50).ToString + " " + (Zpos - 1).ToString +
                  " " + (XposL + 1).ToString + " " + (Ypos - 50 + 4).ToString + " " + (ZposL + 1).ToString +
                  " " + (Xpos - 1).ToString + " " + (Ypos - 4).ToString + " " + (Zpos - 1).ToString + " replace")

        Console.WriteLine("~execute run clone " + (Xpos - 1).ToString + " " + (Ypos - 40).ToString + " " + (Zpos - 1).ToString +
                  " " + (XposL + 1).ToString + " " + (Ypos - 40 + 4).ToString + " " + (ZposL + 1).ToString +
                  " " + (Xpos - 1).ToString + " " + (Ypos + 1).ToString + " " + (Zpos - 1).ToString + " replace")

        Console.WriteLine("~execute run clone " + (Xpos - 1).ToString + " " + (Ypos - 30).ToString + " " + (Zpos - 1).ToString +
                  " " + (XposL + 1).ToString + " " + (Ypos - 30 + 4).ToString + " " + (ZposL + 1).ToString +
                  " " + (Xpos - 1).ToString + " " + (Ypos + 6).ToString + " " + (Zpos - 1).ToString + " replace")



        'Console.WriteLine("~-ss;;;0")
        Console.WriteLine("~-eq;clear")

    End Sub

    Function Get_Legal_Val_Back() As Integer 'Use for return value. 用於取回回傳值

        Dim tmp1, tmp2 As Integer
        Dim tmpstr As String, prefix_str As String
        Dim Loop_TooMany As Integer

        Do
            tmpstr = Console.ReadLine()

            'you may input exit when manual debugging.
            '你可以在手動除錯時輸入 exit 來離開
            If tmpstr = "exit" Then
                Console.WriteLine("Got EXIT.")
                Console.ReadLine()
                End
            End If

            tmp1 = InStr(tmpstr, "*")

            If tmp1 > 0 Then

                prefix_str = tmpstr.Substring(0, tmp1)

                'When sending, we used *maze for prefix, the return is maze* start.
                '由於我們發送時使用了 *maze 做前綴，所以回傳值會用 maze* 做前綴
                '不是此前綴代表不是我們要的

                If prefix_str = "maze*" Then

                    tmpstr = tmpstr.Substring(tmp1)

                    ' -1 means 4WMC over busy, not usually.
                    ' -1 代表 4WMC 過於忙碌, 通常不應發生
                    If (tmpstr = "-1") Then
                        Console.WriteLine("Got " + tmpstr + ", please check code.")
                        Console.ReadLine()
                        End
                        ' -2 or -4 means the target is not be found. 
                        ' Whether it is an error, or how to dispose, depend on your using scenes. 
                        ' -2 或 -4 代表 目標未發現，是否是錯誤、或該如何處置取決於你的使用場合。
                    ElseIf (tmpstr = "-2") OrElse (tmpstr = "-4") Then
                        Console.WriteLine("Got " + tmpstr + ", please check code.")
                        Exit Function
                    Else
                        'Get the value 取回值
                        tmp1 = InStr(tmpstr, ":") + 1
                        tmp2 = tmpstr.Length - 1
                        Return Fix(Val(tmpstr.Substring(tmp1, tmp2 - tmp1)))
                    End If

                End If
            End If


            Loop_TooMany += 1

        Loop Until Loop_TooMany > 10

        'Loop over 10 times, means someting not correct.
        '取超過十次仍未取得值，代表可能有東西出錯了
        Console.WriteLine("Loop too many times, please check code.")
        Console.ReadLine()
        End

    End Function

    Function Get_IF_Its_Cheast() As Integer

        Dim tmp1 As Integer
        Dim tmpstr As String, prefix_str As String
        Dim Loop_TooMany As Integer

        Do
            tmpstr = Console.ReadLine()

            If tmpstr = "exit" Then
                Console.WriteLine("Got EXIT.")
                Console.ReadLine()
                End
            End If

            tmp1 = InStr(tmpstr, "*")

            If tmp1 > 0 Then

                prefix_str = tmpstr.Substring(0, tmp1)

                If prefix_str = "maze*" Then

                    tmpstr = tmpstr.Substring(tmp1)

                    If tmpstr = "-1" Then 'error: too busy. 錯誤:系統太忙碌。
                        Console.WriteLine("Got " + tmpstr + ", please check code.")
                        Console.ReadLine()
                        End
                    ElseIf tmpstr = "-2" Or tmpstr = "-4" Then　'not found chest 沒找到箱子
                        Return 0
                    ElseIf InStr(tmpstr, "writable_book") > 0 Then 'book in chest, return 1 有箱子有書 傳回1
                        Return 1
                    ElseIf InStr(tmpstr, "writable_book") = 0 Then 'book not in chest, return 2 有箱子沒書 傳回2
                        Return 2
                    End If

                End If
            End If

            Loop_TooMany += 1

        Loop Until Loop_TooMany > 10

        Console.WriteLine("Loop too many, please check code.")
        Console.ReadLine()
        End

    End Function

    'Dim thread2 As New Threading.Thread(Sub() ReadConsole())
    'thread2.Start()

    'Public Sub ReadConsole()

    '    Dim EXIT_Chk As String
    '    EXIT_Chk = Console.ReadLine()

    '    'System.Console.ReadKey(True)
    '    If EXIT_Chk = "exit" Then IamQuit = True
    '    'It's dirty more then political (maybe)

    'End Sub

End Module
