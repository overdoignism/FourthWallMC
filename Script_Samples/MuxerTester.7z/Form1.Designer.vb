﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請勿使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.BoxRefreshTimer = New System.Windows.Forms.Timer(Me.components)
        Me.ScriptConsoleRTbox = New System.Windows.Forms.RichTextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button01 = New System.Windows.Forms.Button()
        Me.Button03 = New System.Windows.Forms.Button()
        Me.Button02 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button04 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(765, 425)
        Me.Button1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(74, 67)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Send"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'BoxRefreshTimer
        '
        Me.BoxRefreshTimer.Enabled = True
        Me.BoxRefreshTimer.Interval = 500
        '
        'ScriptConsoleRTbox
        '
        Me.ScriptConsoleRTbox.BackColor = System.Drawing.Color.Black
        Me.ScriptConsoleRTbox.Font = New System.Drawing.Font("Courier New", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ScriptConsoleRTbox.ForeColor = System.Drawing.Color.Silver
        Me.ScriptConsoleRTbox.Location = New System.Drawing.Point(12, 13)
        Me.ScriptConsoleRTbox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ScriptConsoleRTbox.Name = "ScriptConsoleRTbox"
        Me.ScriptConsoleRTbox.ReadOnly = True
        Me.ScriptConsoleRTbox.Size = New System.Drawing.Size(736, 430)
        Me.ScriptConsoleRTbox.TabIndex = 6
        Me.ScriptConsoleRTbox.Text = "Here we go"
        Me.ScriptConsoleRTbox.WordWrap = False
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(12, 459)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(736, 32)
        Me.TextBox1.TabIndex = 7
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(848, 425)
        Me.Button2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(74, 67)
        Me.Button2.TabIndex = 8
        Me.Button2.Text = "Exit"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button01
        '
        Me.Button01.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button01.Location = New System.Drawing.Point(765, 50)
        Me.Button01.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button01.Name = "Button01"
        Me.Button01.Size = New System.Drawing.Size(157, 67)
        Me.Button01.TabIndex = 9
        Me.Button01.Text = "Test worker present"
        Me.Button01.UseVisualStyleBackColor = True
        '
        'Button03
        '
        Me.Button03.Enabled = False
        Me.Button03.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button03.Location = New System.Drawing.Point(765, 250)
        Me.Button03.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button03.Name = "Button03"
        Me.Button03.Size = New System.Drawing.Size(157, 67)
        Me.Button03.TabIndex = 10
        Me.Button03.Text = "Get sender's position info"
        Me.Button03.UseVisualStyleBackColor = True
        '
        'Button02
        '
        Me.Button02.Enabled = False
        Me.Button02.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button02.Location = New System.Drawing.Point(765, 149)
        Me.Button02.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button02.Name = "Button02"
        Me.Button02.Size = New System.Drawing.Size(157, 67)
        Me.Button02.TabIndex = 11
        Me.Button02.Text = "Get sender info"
        Me.Button02.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(754, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(177, 24)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "w/ 4WMC Worker"
        '
        'Button04
        '
        Me.Button04.Enabled = False
        Me.Button04.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button04.Location = New System.Drawing.Point(765, 349)
        Me.Button04.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button04.Name = "Button04"
        Me.Button04.Size = New System.Drawing.Size(157, 67)
        Me.Button04.TabIndex = 13
        Me.Button04.Text = "Make a tree at sender"
        Me.Button04.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(750, 121)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(190, 24)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "?"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(750, 222)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(190, 24)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "?"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(750, 321)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(190, 24)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "?"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(943, 507)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button04)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button02)
        Me.Controls.Add(Me.Button03)
        Me.Controls.Add(Me.Button01)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.ScriptConsoleRTbox)
        Me.Controls.Add(Me.Button1)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "FourthWallMC MuxerTester"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Windows.Forms.Button
    Friend WithEvents BoxRefreshTimer As Windows.Forms.Timer
    Friend WithEvents ScriptConsoleRTbox As Windows.Forms.RichTextBox
    Friend WithEvents TextBox1 As Windows.Forms.TextBox
    Friend WithEvents Button2 As Windows.Forms.Button
    Friend WithEvents Button01 As Windows.Forms.Button
    Friend WithEvents Button03 As Windows.Forms.Button
    Friend WithEvents Button02 As Windows.Forms.Button
    Friend WithEvents Label1 As Windows.Forms.Label
    Friend WithEvents Button04 As Windows.Forms.Button
    Friend WithEvents Label2 As Windows.Forms.Label
    Friend WithEvents Label3 As Windows.Forms.Label
    Friend WithEvents Label4 As Windows.Forms.Label
End Class
