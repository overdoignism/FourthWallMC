﻿Imports System.ComponentModel
Imports System.Windows.Forms

Public Class Form1
    Structure ScriptCake
        Dim Script_Process As System.Diagnostics.Process
        Dim Script_myStreamWriter As System.IO.StreamWriter
        Dim Is_Working As Boolean
        Dim Script_Exec_Total_String As String
        Dim PID As Integer

        Dim MC_Specify_Prefix As String
        Dim Script_Specify_Prefix As String
        Dim Work_start_ticket As Long
        Dim Is_Recive_Anything_RAW As Integer

    End Structure

    Structure ScriptLog
        Dim Script_String_Log As String
        Dim The_Slot As String
    End Structure

    Const VBString_Max As Integer = 8192
    Dim Very_Big_String(VBString_Max - 1) As String
    Dim Very_Big_Idx As Integer

    Dim CommandSender As String
    Dim World, X, Y, Z As String


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim thread As New Threading.Thread(Sub() Main_Console_Recive())
        thread.Start()

    End Sub

    Private Sub Main_Console_Recive()

        Dim What_Console_Read As String

        Do
            What_Console_Read = Console.ReadLine

            If What_Console_Read.StartsWith("VerTest*") Then
                Dim TEST_VER As Single = Val(What_Console_Read.Substring(8))
                If TEST_VER >= 1 Then
                    Button02.Enabled = True
                    Label2.Text = "Worker ver:" + Format(TEST_VER, "0.00")
                End If
            End If

            If What_Console_Read.StartsWith("GetSender*") Then
                CommandSender = What_Console_Read.Substring(10)
                Label3.Text = CommandSender
                Button03.Enabled = True
            End If

            If What_Console_Read.StartsWith("GetWorld*") Then
                Dim TMP() As String = What_Console_Read.Substring(9).Split(";")
                World = TMP(0)
                X = TMP(1)
                Y = TMP(2)
                Z = TMP(3)
                Label4.Text = World + "," + X + "," + Y + "," + Z
                Button04.Enabled = True
            End If


            Very_Big_Idx = Very_Big_Idx Mod VBString_Max
            Very_Big_String(Very_Big_Idx) = What_Console_Read
            Very_Big_Idx += 1
        Loop

    End Sub

    Private Sub BoxRefreshTimer_Tick(sender As Object, e As EventArgs) Handles BoxRefreshTimer.Tick

        Dim Show_String2 As String = ""
        Dim Tmp_Index1 As Integer
        Dim LittleShowIdx As Integer


        For Tmp_Index1 = Very_Big_Idx - 1 To 0 Step -1
            If LittleShowIdx = 47 Then Exit For
            Show_String2 = Very_Big_String(Tmp_Index1) + vbCrLf + Show_String2
            LittleShowIdx += 1
        Next
        For Tmp_Index1 = VBString_Max - 1 To Very_Big_Idx Step -1
            If LittleShowIdx = 47 Then Exit For
            If Very_Big_String(Tmp_Index1) <> "" Then Show_String2 = Very_Big_String(Tmp_Index1) + vbCrLf + Show_String2
            LittleShowIdx += 1
        Next

        ScriptConsoleRTbox.Text = Show_String2
        ' BoxRefreshTimer.Enabled = False

    End Sub


    Private Sub ScriptConsoleRTbox_TextChanged(sender As Object, e As EventArgs) Handles ScriptConsoleRTbox.TextChanged
        ScriptConsoleRTbox.SelectionStart = ScriptConsoleRTbox.Text.Length
        ScriptConsoleRTbox.ScrollToCaret()
        System.Windows.Forms.Application.DoEvents()
        ScriptConsoleRTbox.ScrollToCaret()
        System.Windows.Forms.Application.DoEvents()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Console.WriteLine(TextBox1.Text)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        End
    End Sub

    Private Sub TextBox1_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyUp
        If e.KeyCode = Keys.Enter Then
            Console.WriteLine(TextBox1.Text)
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button01.Click
        ScriptConsoleRTbox.Text = ""
        TextBox1.Text = "*VerTest~+4w;fwver"
        Console.WriteLine(TextBox1.Text)

    End Sub

    Private Sub Form1_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        End
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button02.Click
        TextBox1.Text = "*GetSender~+cm;sender"
        Console.WriteLine(TextBox1.Text)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button03.Click
        TextBox1.Text = "*GetWorld~+4w;fwpgetpos;" + CommandSender
        Console.WriteLine(TextBox1.Text)
    End Sub

    Private Sub Button04_Click(sender As Object, e As EventArgs) Handles Button04.Click
        TextBox1.Text = "*MakeTree~+4w;fwctree;" + World + ";TREE;" + X + ";" + Y + ";" + Z
        Console.WriteLine(TextBox1.Text)
    End Sub
End Class