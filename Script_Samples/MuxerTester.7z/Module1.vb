﻿Imports System.Drawing
Imports System.Drawing.Text
Imports System.Management

Module Module1

    Sub Main()

        Windows.Forms.Application.EnableVisualStyles()
        Windows.Forms.Application.SetCompatibleTextRenderingDefault(False)
        Windows.Forms.Application.Run(New Form1())


    End Sub
    Public Sub killChildrenProcessesOf(ByVal parentProcessId As UInt32)

        Dim searcher As New ManagementObjectSearcher("SELECT * FROM Win32_Process WHERE ParentProcessId=" & parentProcessId)

        Dim Collection As ManagementObjectCollection
        Collection = searcher.Get()

        If (Collection.Count > 0) Then

            For Each item In Collection
                Dim childProcessId As Int32
                childProcessId = Convert.ToInt32(item("ProcessId"))
                If Not (childProcessId = Process.GetCurrentProcess().Id) Then

                    killChildrenProcessesOf(childProcessId)

                    Dim childProcess As Process
                    childProcess = Process.GetProcessById(childProcessId)
                    childProcess.Kill()
                End If
            Next
        End If
    End Sub


End Module
